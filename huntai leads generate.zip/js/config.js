// HuntAI - Firebase Configuration
const firebaseConfig = {
    apiKey: "AIzaSyBVUKRYeQDFWMmnNqyrgrkPbDy96QpcVLU",
    authDomain: "zenthos-academy.firebaseapp.com",
    projectId: "zenthos-academy",
    storageBucket: "zenthos-academy.firebasestorage.app",
    messagingSenderId: "1039146199166",
    appId: "1:1039146199166:android:f6f8ac3b27ffb15cb7502f"
};

// Initialize Firebase
if (!firebase.apps.length) {
    firebase.initializeApp(firebaseConfig);
}
const auth = firebase.auth();
const db = firebase.firestore();
const ADMIN_EMAIL = "admin@huntai.com";

// Admin Security Check
function checkAdminAccess() {
    auth.onAuthStateChanged(user => {
        if (!user || user.email !== ADMIN_EMAIL) {
            window.location.href = 'dashboard.html';
        }
    });
}